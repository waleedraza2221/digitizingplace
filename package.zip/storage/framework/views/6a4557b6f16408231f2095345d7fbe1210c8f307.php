<!DOCTYPE html>
<html lang="en-US">
  <head>
    <meta charset="utf-8" />
  </head>
  <body>
    <h2>Password Reset Link</h2>
    <p><?php echo e($test_message); ?></p>
  </body>
</html><?php /**PATH C:\xampp\htdocs\digitizingplace\resources\views/emails/test.blade.php ENDPATH**/ ?>