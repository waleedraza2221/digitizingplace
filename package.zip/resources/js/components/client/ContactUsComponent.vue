<template>

 <v-container
       
        fluid
    
      >
        <iframe  src="https://tawk.to/chat/5ebb15a28ee2956d73a08954/default"></iframe>
  
      </v-container>
    


</template>
<script>
export default {
    mounted() {
            console.log('Contact Us Component mounted.')
        }
}
</script>
<style scoped>

</style>