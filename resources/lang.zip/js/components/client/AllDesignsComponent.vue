<template>

  <v-container fluid>
    <v-data-iterator
      :items="items"
      :items-per-page.sync="itemsPerPage"
      :page="page"
      :search="search"
      :sort-by="sortBy.toLowerCase()"
      :sort-desc="sortDesc"
      hide-default-footer
    >
      <template v-slot:header>
        <v-toolbar
          dark
          color="amber darken-3"
          class="mb-1"
        >
          <v-text-field
            v-model="search"
            clearable
            flat
            solo-inverted
            hide-details
            prepend-inner-icon="mdi-magnify"
            label="Search"
          ></v-text-field>
          <template v-if="$vuetify.breakpoint.mdAndUp">
            <v-spacer></v-spacer>
            <v-select
              v-model="sortBy"
              flat
              solo-inverted
              hide-details
              :items="keys"
              prepend-inner-icon="mdi-magnify"
              label="Sort by"
            ></v-select>
            <v-spacer></v-spacer>
            <v-btn-toggle
              v-model="sortDesc"
              mandatory
            >
              <v-btn
                large
                depressed
                color="amber"
                :value="false"
              >
                <v-icon>mdi-arrow-up</v-icon>
              </v-btn>
              <v-btn
                large
                depressed
                color="amber"
                :value="true"
              >
                <v-icon>mdi-arrow-down</v-icon>
              </v-btn>
            </v-btn-toggle>
          </template>
        </v-toolbar>
      </template>

      <template v-slot:default="props">
        <v-row>
          <v-col
            v-for="item in props.items"
            :key="item.name"
            cols="12"
            sm="6"
            md="4"
            lg="3"
          >


           <v-hover>
    <template v-slot:default="{ hover }">
      <v-card
        class="mx-auto"
        max-width="344"
      >
        <v-parallax src="https://cdn.vuetifyjs.com/images/parallax/material.jpg" height="250"></v-parallax>

        <v-card-text>
          <h2 class="title primary--text">{{item.name}}</h2>
        
        </v-card-text>
        <v-fade-transition>
          <v-overlay
            v-if="hover"
            absolute
            color="#036358"
          >
            <v-btn 
            :to="{ name: 'show', query: { id: item.id }}"
            >Open</v-btn>
          </v-overlay>
        </v-fade-transition>
      </v-card>
    </template>
  </v-hover>


            <!-- <v-card>
              <v-card-title class="subheading font-weight-bold">{{ item.name  }} 52.00 </v-card-title>

              <v-divider></v-divider>
             <v-parallax height="250" src={{ item.image  }}></v-parallax>
             <v-divider></v-divider>
              <v-list dense>
                
                <v-list-item
                  v-for="(key, index) in filteredKeys"
                  :key="index"
                >
                  <v-list-item-content :class="{ 'blue--text': sortBy === key }">{{ key }}:</v-list-item-content>
                  <v-list-item-content class="align-end" :class="{ 'blue--text': sortBy === key }">{{ item[key.toLowerCase()] }}</v-list-item-content>
                </v-list-item>
              </v-list>
            </v-card> -->

          </v-col>
        </v-row>
      </template>

      <template v-slot:footer>
        <v-row class="mt-2" align="center" justify="center">
          <span class="grey--text">Items per page</span>
          <v-menu offset-y>
            <template v-slot:activator="{ on, attrs }">
              <v-btn
                dark
                text
                color="amber"
                class="ml-2"
                v-bind="attrs"
                v-on="on"
              >
                {{ itemsPerPage }}
                <v-icon>mdi-chevron-down</v-icon>
              </v-btn>
            </template>
            <v-list>
              <v-list-item
                v-for="(number, index) in itemsPerPageArray"
                :key="index"
                @click="updateItemsPerPage(number)"
              >
                <v-list-item-title>{{ number }}</v-list-item-title>
              </v-list-item>
            </v-list>
          </v-menu>

          <v-spacer></v-spacer>

          <span
            class="mr-4
            grey--text"
          >
            Page {{ page }} of {{ numberOfPages }}
          </span>
          <v-btn
            fab
            dark
            color="amber darken-3"
            class="mr-1"
            @click="formerPage"
          >
            <v-icon>mdi-chevron-left</v-icon>
          </v-btn>
          <v-btn
            fab
            dark
            color="amber darken-3"
            class="ml-1"
            @click="nextPage"
          >
            <v-icon>mdi-chevron-right</v-icon>
          </v-btn>
        </v-row>
      </template>
    </v-data-iterator>
  </v-container>
    


</template>
<script>
  export default {
    data () {
      return {
        itemsPerPageArray: [32, 64, 96],
        search: '',
        filter: {},
        sortDesc: false,
        page: 1,
        itemsPerPage: 32,
        sortBy: 'name',
        keys: [
          'Name',
          'Image',
          'Id'
        ],
        items: [
          {
            name: 'Frozen Yogurt',
            image: 'https://cdn.vuetifyjs.com/images/parallax/material.jpg',
           id:1
          },
         
    
          {
            name: 'KitKat',
            image: 'https://cdn.vuetifyjs.com/images/parallax/material.jpg',
            id:2
          },
           {
            name: 'KitKat',
            image: 'https://cdn.vuetifyjs.com/images/parallax/material.jpg',
            id:2
          },
           {
            name: 'KitKat',
            image: 'https://cdn.vuetifyjs.com/images/parallax/material.jpg',
            id:2
          },
           {
            name: 'KitKat',
            image: 'https://cdn.vuetifyjs.com/images/parallax/material.jpg',
            id:2
          },
           {
            name: 'KitKat',
            image: 'https://cdn.vuetifyjs.com/images/parallax/material.jpg',
            id:2
          },
           {
            name: 'KitKat',
            image: 'https://cdn.vuetifyjs.com/images/parallax/material.jpg',
            id:2
          },
           {
            name: 'KitKat',
            image: 'https://cdn.vuetifyjs.com/images/parallax/material.jpg',
            id:2
          },
           {
            name: 'KitKat',
            image: 'https://cdn.vuetifyjs.com/images/parallax/material.jpg',
            id:2
          },
           {
            name: 'KitKat',
            image: 'https://cdn.vuetifyjs.com/images/parallax/material.jpg',
            id:2
          },
           {
            name: 'KitKat',
            image: 'https://cdn.vuetifyjs.com/images/parallax/material.jpg',
            id:2
          },
           {
            name: 'KitKat',
            image: 'https://cdn.vuetifyjs.com/images/parallax/material.jpg',
            id:2
          },
           {
            name: 'KitKat',
            image: 'https://cdn.vuetifyjs.com/images/parallax/material.jpg',
            id:2
          },
           {
            name: 'KitKat',
            image: 'https://cdn.vuetifyjs.com/images/parallax/material.jpg',
            id:2
          },
           {
            name: 'KitKat',
            image: 'https://cdn.vuetifyjs.com/images/parallax/material.jpg',
            id:2
          },
           {
            name: 'KitKat',
            image: 'https://cdn.vuetifyjs.com/images/parallax/material.jpg',
            id:2
          },
           {
            name: 'KitKat',
            image: 'https://cdn.vuetifyjs.com/images/parallax/material.jpg',
            id:2
          },
           {
            name: 'KitKat',
            image: 'https://cdn.vuetifyjs.com/images/parallax/material.jpg',
            id:2
          },
           {
            name: 'KitKat',
            image: 'https://cdn.vuetifyjs.com/images/parallax/material.jpg',
            id:2
          },
           {
            name: 'KitKat',
            image: 'https://cdn.vuetifyjs.com/images/parallax/material.jpg',
            id:2
          },
           {
            name: 'KitKat',
            image: 'https://cdn.vuetifyjs.com/images/parallax/material.jpg',
            id:2
          },
           {
            name: 'KitKat',
            image: 'https://cdn.vuetifyjs.com/images/parallax/material.jpg',
            id:2
          },
           {
            name: 'KitKat',
            image: 'https://cdn.vuetifyjs.com/images/parallax/material.jpg',
            id:2
          }
        ],
      }
    },
    computed: {
      numberOfPages () {
        return Math.ceil(this.items.length / this.itemsPerPage)
      },
      filteredKeys () {
        return this.keys.filter(key => key !== `Name`)
      },
    },
    methods: {
    

      nextPage () {
        if (this.page + 1 <= this.numberOfPages) this.page += 1
      },
      formerPage () {
        if (this.page - 1 >= 1) this.page -= 1
      },
      updateItemsPerPage (number) {
        this.itemsPerPage = number
      },
    },
  }
</script>
<style scoped>

</style>