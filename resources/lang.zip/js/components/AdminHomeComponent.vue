<template>


</template>
<script>
export default {
    mounted() {
            console.log('Admin Home Component mounted.')
        }
}
</script>
<style scoped>

</style>