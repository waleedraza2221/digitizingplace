Client is waiting for Quote of the Id {{$body_message}} Please Click Below Link to send Direct Quote.
                                        